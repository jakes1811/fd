from app.services.transaction_service import TransactionService


transaction_service = TransactionService()

print("SINGLE TRANSACTION:")
print(transaction_service.get_transaction(4))

print("\nFD TRANSACTIONS:")
print(transaction_service.get_fd_transactions(7))

print("\nCUSTOMER TRANSACTIONS:")
print(transaction_service.get_customer_transactions(3))

print("\nALL TRANSACTIONS:")
print(transaction_service.get_all_transactions())