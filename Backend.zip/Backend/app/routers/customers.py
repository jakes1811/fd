from datetime import date

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.customer_services import CustomerService


router = APIRouter(prefix="/customers", tags=["Customers"])

customer_service = CustomerService()


class CustomerCreateRequest(BaseModel):
    user_id: int
    username: str
    password: str
    full_name: str
    date_of_birth: date
    phone: str
    email: str
    address: str


class CustomerUpdateRequest(BaseModel):
    full_name: str
    date_of_birth: date
    phone: str
    email: str
    address: str


@router.post("/")
def create_customer(data: CustomerCreateRequest):
    result = customer_service.create_customer(
        data.user_id,
        data.username,
        data.password,
        data.full_name,
        data.date_of_birth,
        data.phone,
        data.email,
        data.address
    )

    if result is None:
        raise HTTPException(status_code=400, detail="Customer creation failed")

    return result


@router.get("/")
def get_all_customers():
    return customer_service.get_all_customers()


@router.get("/{customer_id}")
def get_customer(customer_id: int):
    result = customer_service.get_customer(customer_id)

    if result is None:
        raise HTTPException(status_code=404, detail="Customer not found")

    return result


@router.put("/{customer_id}")
def update_customer(customer_id: int, data: CustomerUpdateRequest):
    result = customer_service.update_customer(
        customer_id,
        data.full_name,
        data.date_of_birth,
        data.phone,
        data.email,
        data.address
    )

    if result is None:
        raise HTTPException(status_code=404, detail="Customer not found")

    return result


@router.patch("/{customer_id}/deactivate")
def deactivate_customer(customer_id: int):
    result = customer_service.deactivate_customer(customer_id)

    if result is None:
        raise HTTPException(status_code=404, detail="Customer not found")

    return result