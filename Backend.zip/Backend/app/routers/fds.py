from datetime import date

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.fd_services import FDService


router = APIRouter(prefix="/fds", tags=["Fixed Deposits"])

fd_service = FDService()


class FDCreateRequest(BaseModel):
    customer_id: int
    principal_amount: float
    interest_rate: float
    tenure_months: int
    start_date: date


class PrematureClosureRequest(BaseModel):
    closure_date: date


@router.post("/")
def create_fd(data: FDCreateRequest):
    result = fd_service.create_fd(
        data.customer_id,
        data.principal_amount,
        data.interest_rate,
        data.tenure_months,
        data.start_date
    )

    if result is None:
        raise HTTPException(status_code=400, detail="FD creation failed")

    return result


@router.get("/customer/{customer_id}")
def get_customer_fds(customer_id: int):
    result = fd_service.get_customer_fds(customer_id)

    if result is None:
        raise HTTPException(status_code=404, detail="Customer not found")

    return result


@router.get("/{fd_id}")
def get_fd(fd_id: int):
    result = fd_service.get_fd(fd_id)

    if result is None:
        raise HTTPException(status_code=404, detail="FD not found")

    return result


@router.post("/{fd_id}/premature-request")
def request_premature_closure(fd_id: int, data: PrematureClosureRequest):
    result = fd_service.request_premature_closure(fd_id, data.closure_date)

    if result is None:
        raise HTTPException(status_code=400, detail="Premature closure request failed")

    return result


@router.post("/{fd_id}/premature-approve")
def approve_premature_closure(fd_id: int, admin_user_id: int):
    result = fd_service.approve_premature_closure(fd_id, admin_user_id)

    if result is None:
        raise HTTPException(status_code=400, detail="Premature closure approval failed")

    return result


@router.post("/{fd_id}/premature-reject")
def reject_premature_closure(fd_id: int, admin_user_id: int):
    result = fd_service.reject_premature_closure(fd_id, admin_user_id)

    if result is None:
        raise HTTPException(status_code=400, detail="Premature closure rejection failed")

    return result

@router.post("/{fd_id}/maturity")
def process_maturity(fd_id: int, admin_user_id: int):
    result = fd_service.process_maturity(fd_id, admin_user_id)

    if result is None:
        raise HTTPException(status_code=400, detail="Maturity processing failed")

    return result