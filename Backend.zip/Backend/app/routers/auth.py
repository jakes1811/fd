from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.auth_services import AuthService


router = APIRouter(prefix="/auth", tags=["Authentication"])

auth_service = AuthService()


class LoginRequest(BaseModel):
    email: str
    password: str


@router.post("/login")
def login(data: LoginRequest):
    result = auth_service.login(data.email, data.password)

    if result is None:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    return result