from fastapi import APIRouter, HTTPException

from app.services.transaction_service import TransactionService


router = APIRouter(prefix="/transactions", tags=["Transactions"])

transaction_service = TransactionService()


@router.get("/")
def get_all_transactions():
    return transaction_service.get_all_transactions()


@router.get("/fd/{fd_id}")
def get_fd_transactions(fd_id: int):
    return transaction_service.get_fd_transactions(fd_id)


@router.get("/customer/{customer_id}")
def get_customer_transactions(customer_id: int):
    return transaction_service.get_customer_transactions(customer_id)


@router.get("/{transaction_id}")
def get_transaction(transaction_id: int):
    result = transaction_service.get_transaction(transaction_id)

    if result is None:
        raise HTTPException(status_code=404, detail="Transaction not found")

    return result