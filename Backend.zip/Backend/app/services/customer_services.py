import bcrypt

from app.repositories.user_repository import user_repository
from app.repositories.customer_repository import customer_repository


class CustomerService:

    def __init__(self):
        self.user_repo = user_repository()
        self.customer_repo = customer_repository()

    def create_customer(self, user_id, username, password, full_name, date_of_birth, phone, email, address):
        hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode()

        self.user_repo.create_user(user_id, username, email, hashed_password, "CUSTOMER")

        self.customer_repo.create_customer(
            user_id, full_name, date_of_birth, phone, email, address
        )

        return self.customer_repo.get_customer_by_userid(user_id)

    def get_customer(self, customer_id):
        return self.customer_repo.get_customer_by_custid(customer_id)

    def get_all_customers(self):
        return self.customer_repo.get_all_customers()

    def update_customer(self, customer_id, full_name, date_of_birth, phone, email, address):
        customer = self.customer_repo.get_customer_by_custid(customer_id)

        if customer is None:
            return None

        self.customer_repo.update_customer(
            customer_id, full_name, date_of_birth, phone, email, address
        )

        return self.customer_repo.get_customer_by_custid(customer_id)

    def deactivate_customer(self, customer_id):
        customer = self.customer_repo.get_customer_by_custid(customer_id)

        if customer is None:
            return None

        user_id = customer[1]

        self.user_repo.update_user_status(user_id, False)
        self.customer_repo.update_customer_status(customer_id, "INACTIVATE")

        return {
            "customer_id": customer_id,
            "user_id": user_id,
            "status": "INACTIVATE",
            "is_active": False
        }