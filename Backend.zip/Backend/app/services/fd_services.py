from decimal import Decimal
from datetime import date
from dateutil.relativedelta import relativedelta

from app.repositories.fd_repository import fd_repository
from app.repositories.customer_repository import customer_repository
from app.repositories.transaction_repository import transaction_repository


class FDService:

    def __init__(self):
        self.fd_repo = fd_repository()
        self.customer_repo = customer_repository()
        self.transaction_repo = transaction_repository()
        self.pending_premature = {}

    def calculate_interest(self, principal_amount, interest_rate, tenure_months):
        principal_amount = Decimal(str(principal_amount))
        interest_rate = Decimal(str(interest_rate))
        tenure_months = Decimal(str(tenure_months))

        interest = (principal_amount * interest_rate * tenure_months) / Decimal("1200")

        return interest.quantize(Decimal("0.01"))

    def calculate_maturity_amount(self, principal_amount, interest):
        principal_amount = Decimal(str(principal_amount))
        interest = Decimal(str(interest))

        return (principal_amount + interest).quantize(Decimal("0.01"))

    def calculate_maturity_date(self, start_date, tenure_months):
        return start_date + relativedelta(months=tenure_months)

    def calculate_completed_months(self, start_date, closure_date):
        if closure_date < start_date:
            return 0

        months = (closure_date.year - start_date.year) * 12
        months += closure_date.month - start_date.month

        if closure_date.day < start_date.day:
            months -= 1

        return months

    def calculate_premature_amount(self, principal_amount, interest_rate, completed_months):
        principal_amount = Decimal(str(principal_amount))
        interest_rate = Decimal(str(interest_rate))

        premature_rate = interest_rate - Decimal("1.00")

        if premature_rate < 0:
            premature_rate = Decimal("0.00")

        interest = self.calculate_interest(
            principal_amount,
            premature_rate,
            completed_months
        )

        return self.calculate_maturity_amount(principal_amount, interest)

    def create_fd(self, customer_id, principal_amount, interest_rate, tenure_months, start_date):
        customer = self.customer_repo.get_customer_by_custid(customer_id)

        if customer is None:
            return None

        if customer[7] != "ACTIVE":
            return None

        principal_amount = Decimal(str(principal_amount))
        interest_rate = Decimal(str(interest_rate))

        if principal_amount <= 0:
            return None

        if interest_rate <= 0:
            return None

        if tenure_months <= 0:
            return None

        interest = self.calculate_interest(principal_amount, interest_rate, tenure_months)
        maturity_amount = self.calculate_maturity_amount(principal_amount, interest)
        maturity_date = self.calculate_maturity_date(start_date, tenure_months)

        self.fd_repo.create_fd(
            customer_id,
            principal_amount,
            interest_rate,
            tenure_months,
            start_date,
            maturity_date,
            maturity_amount
        )

        fds = self.fd_repo.get_fds_by_customerid(customer_id)

        if not fds:
            return None

        fd = fds[-1]
        fd_id = fd[0]

        self.transaction_repo.create_transaction(
            fd_id,
            "FD_CREATED",
            principal_amount,
            f"TXN-{fd_id:06d}",
            "Fixed Deposit Created",
            customer[1]
        )

        return fd

    def get_customer_fds(self, customer_id):
        customer = self.customer_repo.get_customer_by_custid(customer_id)

        if customer is None:
            return None

        return self.fd_repo.get_fds_by_customerid(customer_id)

    def get_fd(self, fd_id):
        return self.fd_repo.get_fd_by_id(fd_id)

    def request_premature_closure(self, fd_id, closure_date):
        fd = self.fd_repo.get_fd_by_id(fd_id)

        if fd is None:
            return None

        if fd[8] != "ACTIVE":
            return None

        if closure_date < fd[5]:
            return None

        if closure_date >= fd[6]:
            return None

        completed_months = self.calculate_completed_months(
            fd[5],
            closure_date
        )

        if completed_months <= 0:
            return None

        premature_amount = self.calculate_premature_amount(
            fd[2],
            fd[3],
            completed_months
        )

        self.pending_premature[fd_id] = {
            "closure_date": closure_date,
            "amount": premature_amount
        }

        self.fd_repo.update_fd_status(fd_id, "PENDING-PREMATURE")

        return {
            "fd_id": fd[0],
            "customer_id": fd[1],
            "principal_amount": fd[2],
            "original_interest_rate": fd[3],
            "premature_interest_rate": max(Decimal("0.00"), fd[3] - Decimal("1.00")),
            "completed_months": completed_months,
            "closure_date": closure_date,
            "premature_amount": premature_amount,
            "status": "PENDING-PREMATURE"
        }

    def process_maturity(self, fd_id, admin_user_id):
        fd = self.fd_repo.get_fd_by_id(fd_id)

        if fd is None:
            return None

        if fd[8] != "ACTIVE":
            return None

        if date.today() < fd[6]:
            return None

        self.fd_repo.update_fd_status(fd_id, "MATURED")

        self.transaction_repo.create_transaction(
            fd_id,
            "MATURITY_PROCESSED",
            fd[7],
            f"MAT-{fd_id}",
            "FD maturity processed",
            admin_user_id
        )

        self.fd_repo.update_fd_status(fd_id, "CLOSED")

        self.transaction_repo.create_transaction(
            fd_id,
            "FD_CLOSED",
            fd[7],
            f"CLOSE-{fd_id}",
            "FD closed after maturity",
            admin_user_id
        )

        return self.fd_repo.get_fd_by_id(fd_id)

    def approve_premature_closure(self, fd_id, admin_user_id):
        fd = self.fd_repo.get_fd_by_id(fd_id)

        if fd is None:
            return None

        if fd[8] != "PENDING-PREMATURE":
            return None

        pending = self.pending_premature.get(fd_id)

        if pending is None:
            return None

        amount = pending["amount"]

        self.fd_repo.update_fd_status(fd_id, "PREMATURE-CLOSED")

        self.transaction_repo.create_transaction(
            fd_id,
            "PREMATURE_WITHDRAWAL",
            amount,
            f"PRE-{fd_id}",
            "Premature withdrawal approved",
            admin_user_id
        )

        self.fd_repo.update_fd_status(fd_id, "CLOSED")

        self.transaction_repo.create_transaction(
            fd_id,
            "FD_CLOSED",
            amount,
            f"CLOSE-{fd_id}",
            "FD closed after premature withdrawal",
            admin_user_id
        )

        del self.pending_premature[fd_id]

        return self.fd_repo.get_fd_by_id(fd_id)
    def reject_premature_closure(self, fd_id, admin_user_id):
        fd = self.fd_repo.get_fd_by_id(fd_id)

        if fd is None:
            return None

        if fd[8] != "PENDING-PREMATURE":
            return None

        self.fd_repo.update_fd_status(fd_id, "ACTIVE")

        return self.fd_repo.get_fd_by_id(fd_id)