import bcrypt

from app.repositories.user_repository import user_repository


class AuthService:

    def __init__(self):
        self.user_repo = user_repository()

    def login(self, email, password):
        user = self.user_repo.get_user_by_email(email)

        if user is None:
            return None

        stored_hash = user[3]

        if not bcrypt.checkpw(
            password.encode("utf-8"),
            stored_hash.encode("utf-8")
        ):
            return None

        if not user[5]:
            return None

        return {
            "user_id": user[0],
            "username": user[1],
            "email": user[2],
            "role": user[4],
            "is_active": user[5]
        }