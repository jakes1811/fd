from app.repositories.transaction_repository import transaction_repository


class TransactionService:

    def __init__(self):
        self.transaction_repo = transaction_repository()

    def get_transaction(self, transaction_id):
        return self.transaction_repo.get_transaction_by_id(transaction_id)

    def get_fd_transactions(self, fd_id):
        return self.transaction_repo.get_transactions_by_fd(fd_id)

    def get_customer_transactions(self, customer_id):
        return self.transaction_repo.get_transactions_by_customerid(customer_id)

    def get_all_transactions(self):
        return self.transaction_repo.get_all_transactions()