from app.database import get_connection
class user_repository:
    def get_user_by_email(self,email:str):
        self.email=email
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from users where email=%s",(self.email,))
        result=cur.fetchone()
        connect.close()
        return result
    def get_user_by_id(self,id:int):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from users where user_id=%s",(self.id,))
        result=cur.fetchone()
        connect.close()
        return result
    def create_user(self,user_id,name,email,passwd,role):
        self.user_id=user_id
        self.user_name=name
        self.email=email
        self.passwd=passwd
        self.role=role
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("insert into users (user_id,username,email,password_hash,role)values(%s,%s,%s,%s,%s)",(self.user_id,self.user_name,self.email,self.passwd,self.role))
            print("RECORD INSERTED SUCCESSFULLY")
            connect.commit()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()

    def update_user_status(self,user_id,status):
        self.user_id=user_id
        self.status=status
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("update users set is_active=%s ,updated_at=CURRENT_TIMESTAMP where user_id=%s",(self.status,self.user_id))
            print("RECORD UPDATED SUCCESSFULLY")
            connect.commit()
            connect.close()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()
        
        
