from app.database import get_connection
class customer_repository:
    def create_customer(self,user_id,full_name,date_of_birth,phone,email,address):
        self.user_id=user_id
        self.full_name=full_name
        self.date_of_birth=date_of_birth
        self.phone=phone
        self.email=email
        self.address=address
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("insert into customers (user_id,full_name,date_of_birth,phone,email,address)values(%s,%s,%s,%s,%s,%s)",(self.user_id,self.full_name,self.date_of_birth,self.phone,self.email,self.address))
            print("RECORD INSERTED SUCCESSFULLY")
            connect.commit()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()
    def get_customer_by_custid(self,id:int):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from customers where customer_id=%s",(self.id,))
        result=cur.fetchone()
        connect.close()
        return result
    def get_customer_by_userid(self,id:int):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from customers where user_id=%s",(self.id,))
        result=cur.fetchone()
        connect.close()
        return result
    def get_all_customers(self):
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from customers order by customer_id")
        result=cur.fetchall()
        connect.close()
        return result
    def update_customer(self,customer_id,full_name,date_of_birth,phone,email,address):
        self.customer_id=customer_id
        self.full_name=full_name
        self.date_of_birth=date_of_birth
        self.phone=phone
        self.email=email
        self.address=address
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("update customers set full_name=%s,date_of_birth=%s,phone=%s,email=%s,address=%s where customer_id=%s",(self.full_name,self.date_of_birth,self.phone,self.email,self.address,self.customer_id))
            print("RECORD UPDATED SUCCESSFULLY")
            connect.commit()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()
    def update_customer_status(self,customer_id,status):
        self.customer_id=customer_id
        self.status=status
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("update customers set status=%s ,updated_at=CURRENT_TIMESTAMP where customer_id=%s",(self.status,self.customer_id))
            print("RECORD UPDATED SUCCESSFULLY")
            connect.commit()
            connect.close()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()
        
