from app.database import get_connection


class fd_repository:
    def create_fd(self,customer_id,principal_amount,interest_rate,tenure_months,start_date,maturity_date,maturity_amount):
        self.customer_id=customer_id
        self.principal_amount=principal_amount
        self.interest_rate=interest_rate
        self.tenure_months=tenure_months
        self.start_date=start_date
        self.maturity_date=maturity_date
        self.maturity_amount=maturity_amount
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("insert into fixed_deposits (customer_id,principal_amount,interest_rate,tenure_months,start_date,maturity_date,maturity_amount)values(%s,%s,%s,%s,%s,%s,%s)",(self.customer_id,self.principal_amount,self.interest_rate,self.tenure_months,self.start_date,self.maturity_date,self.maturity_amount))
            print("RECORD INSERTED SUCCESSFULLY")
            connect.commit()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()
    def get_fd_by_id(self,id:int):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_deposits where fd_id=%s",(self.id,))
        result=cur.fetchone()
        connect.close()
        return result
    def get_fds_by_customerid(self,id:int):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_deposits where customer_id=%s",(self.id,))
        result=cur.fetchall()
        connect.close()
        return result
    def get_all_fds(self):
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_deposits order by fd_id")
        result=cur.fetchall()
        connect.close()
        return result
    def update_fd_status(self,fd_id,status):
        self.fd_id=fd_id
        self.status=status

        try:
            connect=get_connection()
            cur=connect.cursor()

            cur.execute(
                "update fixed_deposits set status=%s, updated_at=CURRENT_TIMESTAMP where fd_id=%s",
                (self.status,self.fd_id)
            )

            connect.commit()
            print("RECORD UPDATED SUCCESSFULLY")

        except Exception as e:
            print(f"ERROR:{e}")
            raise

        finally:
            connect.close()
        
