from app.database import get_connection


class transaction_repository:
    def create_transaction(self,fd_id,transaction_type,amount,reference_number,description,created_by):
        self.fd_id=fd_id
        self.transaction_type=transaction_type
        self.amount=amount
        self.reference_number=reference_number
        self.description=description
        self.created_by=created_by
        try:
            connect=get_connection()
            cur=connect.cursor()
            cur.execute("insert into fixed_transactions (fd_id,transaction_type,amount,reference_number,description,created_by)values(%s,%s,%s,%s,%s,%s)",(self.fd_id,self.transaction_type,self.amount,self.reference_number,self.description,self.created_by))
            print("RECORD INSERTED SUCCESSFULLY")
            connect.commit()
        except Exception as e:
            print(f"ERROR:{e}")
        finally:
            connect.close()
    def get_transaction_by_id(self,id):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_transactions where transaction_id=%s",(self.id,))
        result=cur.fetchone()
        connect.close()
        return result
    def get_transactions_by_fd(self,id):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_transactions where fd_id=%s",(self.id,))
        result=cur.fetchall()
        connect.close()
        return result
    def get_transactions_by_customerid(self,id):
        self.id=id
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_transactions t inner join fixed_deposits f on t.fd_id=f.fd_id where f.customer_id=%s",(self.id,))
        result=cur.fetchall()
        connect.close()
        return result
    def get_all_transactions(self):
        connect=get_connection()
        cur=connect.cursor()
        cur.execute("select * from fixed_transactions order by fd_id")
        result=cur.fetchall()
        connect.close()
        return result
        
