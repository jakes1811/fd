from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import get_connection
from app.routers.auth import router as auth_router
from app.routers.customers import router as customer_router
from app.routers.fds import router as fd_router
from app.routers.transaction import router as transaction_router


app = FastAPI(
    title="Fixed Deposit Management System",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(auth_router)
app.include_router(customer_router)
app.include_router(fd_router)
app.include_router(transaction_router)


@app.get("/")
def root():
    return {
        "message": "FDMS API is running"
    }


@app.get("/db-test")
def db_test():
    connection = get_connection()

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT current_database(), current_user;")
            result = cursor.fetchone()

        return {
            "database": result[0],
            "user": result[1],
            "status": "Database Connection Successful"
        }

    finally:
        connection.close()