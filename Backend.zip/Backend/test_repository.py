from app.repositories.user_repository import user_repository
from app.repositories.customer_repository import customer_repository
from app.repositories.fd_repository import fd_repository
from app.repositories.transaction_repository import transaction_repository
from app.services.auth_services import AuthService

from app.services.customer_services import CustomerService





user_repo = user_repository()
customer_repo = customer_repository()
fd_repo = fd_repository()
transaction_repo = transaction_repository()


print("USER:")
print(user_repo.get_user_by_email("admin@fdms.com"))

print("\nCUSTOMER:")
print(customer_repo.get_customer_by_custid(1))

print("\nFD:")
print(fd_repo.get_fd_by_id(1))

print("\nTRANSACTIONS:")
print(transaction_repo.get_transactions_by_fd(1))





auth_service = AuthService()

result = auth_service.login(
    "arun@fdms.com",
    "arun123"
)

print(result)


from app.services.customer_service import CustomerService


customer_service = CustomerService()

result = customer_service.create_customer(
    3,
    "rahul",
    "rahul123",
    "Rahul Kumar",
    "1998-05-10",
    "9876543210",
    "rahul@fdms.com",
    "Chennai, Tamil Nadu"
)

print(result)
