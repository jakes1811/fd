import { useState, useEffect } from "react";

// ---------------------------------------------------------------------------
// FDMS minimal frontend (React version)
// Talks directly to the existing FastAPI backend. No backend code is changed.
// Change API_BASE below if your backend runs on a different host/port.
// ---------------------------------------------------------------------------
const API_BASE = "http://localhost:8000";

async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) {
    const detail = (data && data.detail) ? data.detail : `Request failed (${res.status})`;
    throw new Error(detail);
  }
  return data;
}

function money(v) {
  if (v === null || v === undefined) return "-";
  return "₹" + Number(v).toLocaleString("en-IN", { maximumFractionDigits: 2 });
}

function StatusBadge({ status }) {
  return <span className={`status-badge status-${status}`}>{status}</span>;
}

// ---------------------------------------------------------------------------
// Column layouts returned by the backend (plain SQL tuples -> JSON arrays)
//   users:              [user_id, username, email, password_hash, role, is_active, ...]
//   customers:           [customer_id, user_id, full_name, date_of_birth, phone, email, address, status, ...]
//   fixed_deposits:       [fd_id, customer_id, principal_amount, interest_rate, tenure_months,
//                          start_date, maturity_date, maturity_amount, status, ...]
//   fixed_transactions:   [transaction_id, fd_id, transaction_type, amount, reference_number,
//                          description, created_by, ...]
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Login screen
// ---------------------------------------------------------------------------
function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      const user = await api("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      onLogin(user);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="card center-card">
      <h1>FDMS Login</h1>
      {error && <div className="msg error">{error}</div>}
      <form onSubmit={handleSubmit}>
        <label>Email</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <label>Password</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Shared shell: topbar + tab nav
// ---------------------------------------------------------------------------
function Shell({ user, tab, setTab, onLogout, message, tabs, children }) {
  return (
    <div>
      <div className="topbar">
        <h1>FDMS</h1>
        <div>
          <strong>{user.username}</strong> ({user.role.toUpperCase()})
          <button className="secondary small" onClick={onLogout}>Logout</button>
        </div>
      </div>
      {message && <div className={`msg ${message.type}`}>{message.text}</div>}
      <div className="tabs">
        {tabs.map((t) => (
          <button
            key={t.id}
            className={tab === t.id ? "active" : ""}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div>{children}</div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// ADMIN: Customers tab
// ---------------------------------------------------------------------------
function AdminCustomers({ setMessage, goToFdsFor }) {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // customer row being edited

  async function load() {
    setLoading(true);
    try {
      const data = await api("/customers/");
      setCustomers(data);
    } catch (err) {
      setMessage("error", err.message);
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api("/customers/", {
        method: "POST",
        body: JSON.stringify({
          user_id: Number(fd.get("user_id")),
          username: fd.get("username"),
          password: fd.get("password"),
          full_name: fd.get("full_name"),
          date_of_birth: fd.get("date_of_birth"),
          phone: fd.get("phone"),
          email: fd.get("email"),
          address: fd.get("address"),
        }),
      });
      setMessage("ok", "Customer created.");
      e.target.reset();
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  async function handleDeactivate(id) {
    if (!confirm(`Deactivate customer ${id}?`)) return;
    try {
      await api(`/customers/${id}/deactivate`, { method: "PATCH" });
      setMessage("ok", "Customer deactivated.");
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  async function handleUpdate(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api(`/customers/${editing[0]}`, {
        method: "PUT",
        body: JSON.stringify({
          full_name: fd.get("full_name"),
          date_of_birth: fd.get("date_of_birth"),
          phone: fd.get("phone"),
          email: fd.get("email"),
          address: fd.get("address"),
        }),
      });
      setMessage("ok", "Customer updated.");
      setEditing(null);
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  if (loading) return <div className="card">Loading customers...</div>;

  return (
    <>
      <div className="card">
        <h3>Create Customer</h3>
        <form onSubmit={handleCreate}>
          <label>User ID (numeric, must not already exist)</label>
          <input name="user_id" type="number" required />
          <label>Username</label>
          <input name="username" required />
          <label>Password</label>
          <input name="password" type="password" required />
          <label>Full Name</label>
          <input name="full_name" required />
          <label>Date of Birth</label>
          <input name="date_of_birth" type="date" required />
          <label>Phone</label>
          <input name="phone" required />
          <label>Email</label>
          <input name="email" type="email" required />
          <label>Address</label>
          <input name="address" required />
          <button type="submit">Create Customer</button>
        </form>
      </div>

      <div className="card">
        <h3>All Customers</h3>
        <table>
          <thead>
            <tr>
              <th>Customer ID</th><th>User ID</th><th>Name</th><th>DOB</th>
              <th>Phone</th><th>Email</th><th>Address</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {customers.length === 0 && (
              <tr><td colSpan={9}>No customers yet.</td></tr>
            )}
            {customers.map((c) => (
              <tr key={c[0]}>
                <td>{c[0]}</td>
                <td>{c[1]}</td>
                <td>{c[2]}</td>
                <td>{c[3] ? String(c[3]).slice(0, 10) : ""}</td>
                <td>{c[4]}</td>
                <td>{c[5]}</td>
                <td>{c[6]}</td>
                <td><StatusBadge status={c[7]} /></td>
                <td>
                  <button className="small" onClick={() => setEditing(c)}>Edit</button>
                  <button
                    className="small danger"
                    disabled={c[7] !== "ACTIVE"}
                    onClick={() => handleDeactivate(c[0])}
                  >
                    Deactivate
                  </button>
                  <button className="small secondary" onClick={() => goToFdsFor(c[0])}>
                    View FDs
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="card">
          <h3>Edit Customer #{editing[0]}</h3>
          <form onSubmit={handleUpdate}>
            <label>Full Name</label>
            <input name="full_name" defaultValue={editing[2]} required />
            <label>Date of Birth</label>
            <input name="date_of_birth" type="date" defaultValue={String(editing[3]).slice(0, 10)} required />
            <label>Phone</label>
            <input name="phone" defaultValue={editing[4]} required />
            <label>Email</label>
            <input name="email" type="email" defaultValue={editing[5]} required />
            <label>Address</label>
            <input name="address" defaultValue={editing[6]} required />
            <button type="submit">Save</button>
            <button type="button" className="secondary" onClick={() => setEditing(null)}>Cancel</button>
          </form>
        </div>
      )}
    </>
  );
}

// ---------------------------------------------------------------------------
// ADMIN: Fixed Deposits tab
// ---------------------------------------------------------------------------
function AdminFDs({ setMessage, adminUserId, filterId, setFilterId }) {
  const [fds, setFds] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      if (filterId) {
        setFds(await api(`/fds/customer/${filterId}`));
      } else {
        // "View All FDs" = collect FDs across every customer (matches the
        // documented flow, since the backend only exposes
        // GET /fds/customer/{customer_id}, not a global "all FDs" endpoint).
        const customers = await api("/customers/");
        const results = await Promise.all(
          customers.map((c) => api(`/fds/customer/${c[0]}`).catch(() => []))
        );
        setFds(results.flat());
      }
    } catch (err) {
      setMessage("error", err.message);
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, [filterId]);

  async function handleCreate(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api("/fds/", {
        method: "POST",
        body: JSON.stringify({
          customer_id: Number(fd.get("customer_id")),
          principal_amount: Number(fd.get("principal_amount")),
          interest_rate: Number(fd.get("interest_rate")),
          tenure_months: Number(fd.get("tenure_months")),
          start_date: fd.get("start_date"),
        }),
      });
      setMessage("ok", "Fixed Deposit created.");
      e.target.reset();
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  async function handleApprove(fdId) {
    try {
      await api(`/fds/${fdId}/premature-approve?admin_user_id=${adminUserId}`, { method: "POST" });
      setMessage("ok", "Premature closure approved.");
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  async function handleReject(fdId) {
    try {
      await api(`/fds/${fdId}/premature-reject?admin_user_id=${adminUserId}`, { method: "POST" });
      setMessage("ok", "Premature closure rejected. FD is ACTIVE again.");
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  async function handleMaturity(fdId) {
    try {
      await api(`/fds/${fdId}/maturity?admin_user_id=${adminUserId}`, { method: "POST" });
      setMessage("ok", "Maturity processed.");
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  return (
    <>
      <div className="card">
        <h3>Create Fixed Deposit</h3>
        <form onSubmit={handleCreate}>
          <label>Customer ID</label>
          <input name="customer_id" type="number" required />
          <label>Principal Amount</label>
          <input name="principal_amount" type="number" step="0.01" required />
          <label>Interest Rate (%)</label>
          <input name="interest_rate" type="number" step="0.01" required />
          <label>Tenure (months)</label>
          <input name="tenure_months" type="number" required />
          <label>Start Date</label>
          <input name="start_date" type="date" required />
          <button type="submit">Create FD</button>
        </form>
      </div>

      <div className="card">
        <h3>Fixed Deposits {filterId ? `for Customer #${filterId}` : "(All)"}</h3>
        <label>Filter by Customer ID</label>
        <div style={{ display: "flex", gap: 8 }}>
          <input
            type="number"
            defaultValue={filterId || ""}
            onKeyDown={(e) => { if (e.key === "Enter") setFilterId(e.target.value || null); }}
            id="fd-filter-input"
          />
          <button
            className="small"
            onClick={() => setFilterId(document.getElementById("fd-filter-input").value || null)}
          >
            Filter
          </button>
          <button className="small secondary" onClick={() => setFilterId(null)}>Show All</button>
        </div>

        {loading ? (
          <p>Loading...</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>FD ID</th><th>Customer</th><th>Principal</th><th>Rate</th><th>Tenure</th>
                <th>Start</th><th>Maturity Date</th><th>Maturity Amt</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {fds.length === 0 && <tr><td colSpan={10}>No FDs found.</td></tr>}
              {fds.map((f) => (
                <tr key={f[0]}>
                  <td>{f[0]}</td>
                  <td>{f[1]}</td>
                  <td>{money(f[2])}</td>
                  <td>{f[3]}%</td>
                  <td>{f[4]}</td>
                  <td>{String(f[5]).slice(0, 10)}</td>
                  <td>{String(f[6]).slice(0, 10)}</td>
                  <td>{money(f[7])}</td>
                  <td><StatusBadge status={f[8]} /></td>
                  <td>
                    {f[8] === "PENDING-PREMATURE" && (
                      <>
                        <button className="small success" onClick={() => handleApprove(f[0])}>Approve</button>
                        <button className="small danger" onClick={() => handleReject(f[0])}>Reject</button>
                      </>
                    )}
                    {f[8] === "ACTIVE" && (
                      <button className="small secondary" onClick={() => handleMaturity(f[0])}>Process Maturity</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
// ADMIN: Transactions tab
// ---------------------------------------------------------------------------
function AdminTransactions({ setMessage }) {
  const [mode, setMode] = useState("all");
  const [filterValue, setFilterValue] = useState("");
  const [txns, setTxns] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load(currentMode, value) {
    setLoading(true);
    try {
      let data;
      if (currentMode === "fd" && value) data = await api(`/transactions/fd/${value}`);
      else if (currentMode === "customer" && value) data = await api(`/transactions/customer/${value}`);
      else data = await api("/transactions/");
      setTxns(data);
    } catch (err) {
      setMessage("error", err.message);
    }
    setLoading(false);
  }

  useEffect(() => { load("all", null); }, []);

  return (
    <div className="card">
      <h3>Transactions</h3>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <button
          className={`small ${mode === "all" ? "" : "secondary"}`}
          onClick={() => { setMode("all"); load("all", null); }}
        >
          All
        </button>
        <input
          type="number"
          placeholder="FD ID"
          style={{ width: 120 }}
          value={mode === "fd" ? filterValue : ""}
          onChange={(e) => setFilterValue(e.target.value)}
        />
        <button className="small secondary" onClick={() => { setMode("fd"); load("fd", filterValue); }}>
          By FD
        </button>
        <input
          type="number"
          placeholder="Customer ID"
          style={{ width: 130 }}
          value={mode === "customer" ? filterValue : ""}
          onChange={(e) => setFilterValue(e.target.value)}
        />
        <button className="small secondary" onClick={() => { setMode("customer"); load("customer", filterValue); }}>
          By Customer
        </button>
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Txn ID</th><th>FD ID</th><th>Type</th><th>Amount</th>
              <th>Reference</th><th>Description</th><th>Created By</th>
            </tr>
          </thead>
          <tbody>
            {txns.length === 0 && <tr><td colSpan={7}>No transactions found.</td></tr>}
            {txns.map((t) => (
              <tr key={t[0]}>
                <td>{t[0]}</td>
                <td>{t[1]}</td>
                <td>{t[2]}</td>
                <td>{money(t[3])}</td>
                <td>{t[4]}</td>
                <td>{t[5]}</td>
                <td>{t[6]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// CUSTOMER: Profile tab
// ---------------------------------------------------------------------------
function CustomerProfile({ customer }) {
  if (!customer) return <div className="msg error">Could not find your customer record.</div>;
  const c = customer;
  return (
    <div className="card">
      <h3>My Profile</h3>
      <table>
        <tbody>
          <tr><th>Customer ID</th><td>{c[0]}</td></tr>
          <tr><th>Name</th><td>{c[2]}</td></tr>
          <tr><th>Date of Birth</th><td>{String(c[3]).slice(0, 10)}</td></tr>
          <tr><th>Phone</th><td>{c[4]}</td></tr>
          <tr><th>Email</th><td>{c[5]}</td></tr>
          <tr><th>Address</th><td>{c[6]}</td></tr>
          <tr><th>Status</th><td><StatusBadge status={c[7]} /></td></tr>
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------------------
// CUSTOMER: My FDs tab
// ---------------------------------------------------------------------------
function CustomerFDs({ customer, setMessage }) {
  const [fds, setFds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [requestingFor, setRequestingFor] = useState(null); // fd_id currently requesting closure for
  const [premResult, setPremResult] = useState(null);

  async function load() {
    if (!customer) return;
    setLoading(true);
    try {
      setFds(await api(`/fds/customer/${customer[0]}`));
    } catch (err) {
      setMessage("error", err.message);
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, [customer]);

  async function handleRequestClosure(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const result = await api(`/fds/${requestingFor}/premature-request`, {
        method: "POST",
        body: JSON.stringify({ closure_date: fd.get("closure_date") }),
      });
      setPremResult(result);
      setMessage("ok", "Premature closure requested. Awaiting admin approval.");
      load();
    } catch (err) {
      setMessage("error", err.message);
    }
  }

  if (!customer) return <div className="msg error">Could not find your customer record.</div>;

  return (
    <>
      <div className="card">
        <h3>My Fixed Deposits</h3>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>FD ID</th><th>Principal</th><th>Rate</th><th>Tenure</th>
                <th>Start</th><th>Maturity Date</th><th>Maturity Amt</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {fds.length === 0 && <tr><td colSpan={9}>No fixed deposits yet.</td></tr>}
              {fds.map((f) => (
                <tr key={f[0]}>
                  <td>{f[0]}</td>
                  <td>{money(f[2])}</td>
                  <td>{f[3]}%</td>
                  <td>{f[4]}</td>
                  <td>{String(f[5]).slice(0, 10)}</td>
                  <td>{String(f[6]).slice(0, 10)}</td>
                  <td>{money(f[7])}</td>
                  <td><StatusBadge status={f[8]} /></td>
                  <td>
                    {f[8] === "ACTIVE" && (
                      <button className="small" onClick={() => { setRequestingFor(f[0]); setPremResult(null); }}>
                        Request Premature Closure
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {requestingFor && (
        <div className="card">
          <h3>Request Premature Closure — FD #{requestingFor}</h3>
          <form onSubmit={handleRequestClosure}>
            <label>Closure Date</label>
            <input name="closure_date" type="date" required />
            <button type="submit">Submit Request</button>
          </form>
          {premResult && (
            <table>
              <tbody>
                <tr><th>Principal</th><td>{money(premResult.principal_amount)}</td></tr>
                <tr><th>Original Rate</th><td>{premResult.original_interest_rate}%</td></tr>
                <tr><th>Premature Rate</th><td>{premResult.premature_interest_rate}%</td></tr>
                <tr><th>Completed Months</th><td>{premResult.completed_months}</td></tr>
                <tr><th>Premature Amount</th><td>{money(premResult.premature_amount)}</td></tr>
                <tr><th>Status</th><td><StatusBadge status={premResult.status} /></td></tr>
              </tbody>
            </table>
          )}
        </div>
      )}
    </>
  );
}

// ---------------------------------------------------------------------------
// CUSTOMER: My Transactions tab
// ---------------------------------------------------------------------------
function CustomerTransactions({ customer, setMessage }) {
  const [txns, setTxns] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!customer) return;
    (async () => {
      setLoading(true);
      try {
        setTxns(await api(`/transactions/customer/${customer[0]}`));
      } catch (err) {
        setMessage("error", err.message);
      }
      setLoading(false);
    })();
  }, [customer]);

  if (!customer) return <div className="msg error">Could not find your customer record.</div>;

  return (
    <div className="card">
      <h3>My Transactions</h3>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr><th>Txn ID</th><th>FD ID</th><th>Type</th><th>Amount</th><th>Reference</th><th>Description</th></tr>
          </thead>
          <tbody>
            {txns.length === 0 && <tr><td colSpan={6}>No transactions yet.</td></tr>}
            {txns.map((t) => (
              <tr key={t[0]}>
                <td>{t[0]}</td>
                <td>{t[1]}</td>
                <td>{t[2]}</td>
                <td>{money(t[3])}</td>
                <td>{t[4]}</td>
                <td>{t[5]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Top-level App
// ---------------------------------------------------------------------------
export default function App() {
  const [user, setUser] = useState(() => {
    const saved = sessionStorage.getItem("fdms_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [customer, setCustomer] = useState(null);
  const [tab, setTab] = useState(null);
  const [message, setMessageState] = useState(null);
  const [fdFilterCustomerId, setFdFilterCustomerId] = useState(null);

  function setMessage(type, text) {
    setMessageState({ type, text });
    if (type === "ok") setTimeout(() => setMessageState(null), 3000);
  }

  async function handleLogin(loggedInUser) {
    setUser(loggedInUser);
    sessionStorage.setItem("fdms_user", JSON.stringify(loggedInUser));

    if (loggedInUser.role.toUpperCase() === "CUSTOMER") {
      // No endpoint maps user_id -> customer_id directly, so we look it up
      // from the customer list (element[1] is user_id on each customer row).
      try {
        const customers = await api("/customers/");
        setCustomer(customers.find((c) => c[1] === loggedInUser.user_id) || null);
      } catch (err) {
        setMessage("error", err.message);
      }
      setTab("profile");
    } else {
      setTab("customers");
    }
  }

  function handleLogout() {
    setUser(null);
    setCustomer(null);
    setTab(null);
    sessionStorage.removeItem("fdms_user");
  }

  if (!user) {
    return (
      <div id="app">
        <Login onLogin={handleLogin} />
      </div>
    );
  }

  const role = user.role.toUpperCase();

  if (role === "ADMIN") {
    const tabs = [
      { id: "customers", label: "Customers" },
      { id: "fds", label: "Fixed Deposits" },
      { id: "transactions", label: "Transactions" },
    ];
    const activeTab = tab || "customers";
    return (
      <div id="app">
        <Shell user={user} tab={activeTab} setTab={setTab} onLogout={handleLogout} message={message} tabs={tabs}>
          {activeTab === "customers" && (
            <AdminCustomers
              setMessage={setMessage}
              goToFdsFor={(customerId) => { setFdFilterCustomerId(String(customerId)); setTab("fds"); }}
            />
          )}
          {activeTab === "fds" && (
            <AdminFDs
              setMessage={setMessage}
              adminUserId={user.user_id}
              filterId={fdFilterCustomerId}
              setFilterId={setFdFilterCustomerId}
            />
          )}
          {activeTab === "transactions" && <AdminTransactions setMessage={setMessage} />}
        </Shell>
      </div>
    );
  }

  // CUSTOMER
  const tabs = [
    { id: "profile", label: "Profile" },
    { id: "my-fds", label: "My Fixed Deposits" },
    { id: "my-transactions", label: "My Transactions" },
  ];
  const activeTab = tab || "profile";
  return (
    <div id="app">
      <Shell user={user} tab={activeTab} setTab={setTab} onLogout={handleLogout} message={message} tabs={tabs}>
        {activeTab === "profile" && <CustomerProfile customer={customer} />}
        {activeTab === "my-fds" && <CustomerFDs customer={customer} setMessage={setMessage} />}
        {activeTab === "my-transactions" && <CustomerTransactions customer={customer} setMessage={setMessage} />}
      </Shell>
    </div>
  );
}
