# FDMS – React Frontend

Same minimal app as before, rebuilt in React (`App.js`) so it drops into a
normal React/Vite project structure. No backend code was changed.

## 1. Run the backend

```bash
uvicorn app.main:app --reload
```

Runs on `http://localhost:8000` by default — edit `API_BASE` at the top of
`src/App.js` if yours differs.

## 2. Run this frontend

```bash
npm install
npm run dev
```

Opens on **http://localhost:5173**, which matches the CORS origin already
whitelisted in your backend (`app/main.py`) — no backend changes needed.

## File map

- `src/App.js` — everything: Login, Shell (topbar/tabs), and all six screens
  (Admin: Customers/FDs/Transactions, Customer: Profile/My FDs/My
  Transactions), each as its own function component.
- `src/main.jsx` — mounts `<App />` into `#root`.
- `src/style.css` — same plain stylesheet as the vanilla-JS version.
- `vite.config.js` — configured so `App.js` (not `.jsx`) can contain JSX.

Same backend quirks apply as before (see comments in `App.js`): tuples come
back as JSON arrays read by index, "View All FDs" loops per-customer since
there's no global endpoint, and `admin_user_id` is passed automatically as a
query param on approve/reject/maturity calls.
