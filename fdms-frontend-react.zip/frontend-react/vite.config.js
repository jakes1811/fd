import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// App.js (not App.jsx) contains JSX, so we tell esbuild to parse
// .js files under src/ as JSX rather than plain JS.
export default defineConfig({
  plugins: [react()],
  esbuild: {
    loader: "jsx",
    include: /src\/.*\.js$/,
  },
  optimizeDeps: {
    esbuildOptions: {
      loader: { ".js": "jsx" },
    },
  },
});
